<?php

// no direct access
defined('ADDON_LIBRARY_INC') or die;


class UniteCreatorGridBuilderProvider extends UniteCreatorGridBuilder{
	
	
	/**
	 * constructor
	 */
	public function __construct(){
		
		parent::__construct();
		
	}
	
	
}