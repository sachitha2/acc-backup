<?php 
// no direct access
defined('ADDON_LIBRARY_INC') or die;

$urlCodecanyon = "https://codecanyon.net/item/unlimited-addons-mega-bundle-for-visual-composer/19602316?ref=unitecms";
$urlDocumentation = "http://addon-library.helpsite.io/";
$urlPremium = "http://addon-library.com";

?>

	<div class="uc-content-box">
    	<h2>Welcome To Addon Library for WPBakery Page Builder</h2>
        <p>
			Get access to more than +700 addons and +30 Layouts for WPBakery Page Builder 
		</p>
		<p>
			<a href='<?php echo $urlCodecanyon?>' target='_blank'>GET IT NOW</a>
		</p>
		<p>
			If you already purchased unlimited addons click on the import addons button to import addons.         
		</p>
    </div>
