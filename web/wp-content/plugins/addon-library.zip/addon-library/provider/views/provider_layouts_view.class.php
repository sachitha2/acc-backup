<?php

defined('ADDON_LIBRARY_INC') or die;

class UniteCreatorLayoutsViewProvider extends UniteCreatorLayoutsView{

	
}