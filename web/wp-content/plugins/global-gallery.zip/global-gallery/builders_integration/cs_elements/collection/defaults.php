<?php

/**
 * Defaults Values
 */

return array(
	'cid' 		=> '',
	'filter' 	=> 0,
	'random' 	=> 0,
	
	'overlay'	=> 'default'
);