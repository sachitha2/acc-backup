<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>{{ vc_btn:<?php echo http_build_query( $atts ) ?> }}
