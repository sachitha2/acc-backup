<?php

require_once( 'class-itsec-recaptcha.php' );
$itsec_recaptcha = new ITSEC_Recaptcha();
$itsec_recaptcha->run();
