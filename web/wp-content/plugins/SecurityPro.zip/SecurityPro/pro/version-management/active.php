<?php

require_once( 'class-itsec-version-management.php' );
ITSEC_Version_Management::get_instance();
