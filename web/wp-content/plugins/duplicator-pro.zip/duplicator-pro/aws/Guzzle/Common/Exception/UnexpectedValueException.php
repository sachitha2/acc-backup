<?php

namespace Guzzle\Common\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements GuzzleException {}
